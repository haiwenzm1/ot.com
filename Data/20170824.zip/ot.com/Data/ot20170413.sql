ALTER TABLE `ot_com`.`ot_operate_log` CHANGE `remark` `remark` VARCHAR(1024) CHARSET utf8 COLLATE utf8_general_ci DEFAULT ''  NOT NULL  COMMENT '日志备注';
